# **Card UI - 07**

### [Demo](https://dropways.github.io/card-ui/cards/card-07)

[![Card - 07](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/251510678-a6b74a6c-032b-4ed5-81d6-44125047a133.jpg)](https://dropways.github.io/card-ui/cards/card-07/)

## Note

**For Dropdown and other javascript action we used**

[![alpinejs](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/250278992-60746a40-ffc9-48fc-a6bb-3a7e8e92903f.svg)](https://alpinejs.dev/)

**Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".**
