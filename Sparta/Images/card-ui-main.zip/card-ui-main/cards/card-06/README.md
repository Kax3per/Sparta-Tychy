# **Card UI - 06**

### [Demo](https://dropways.github.io/card-ui/cards/card-06)

[![Card - 06](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/251437013-a696e871-8250-4ad9-bbe1-ba54b7c34035.jpg)](https://dropways.github.io/card-ui/cards/card-06/)

## Note

**For Dropdown and other javascript action we used**

[![alpinejs](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/250278992-60746a40-ffc9-48fc-a6bb-3a7e8e92903f.svg)](https://alpinejs.dev/)

**Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".**
