**Card UI - 02**
=========

### [Demo](https://dropways.github.io/card-ui/cards/card-02)

[![Card - 02](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/250279355-760837dd-dfeb-44d9-9583-88ad256047c7.jpg)](https://dropways.github.io/card-ui/cards/card-02/)

## Note
**For Dropdown and other javascript action we used**

[![alpinejs](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/250278992-60746a40-ffc9-48fc-a6bb-3a7e8e92903f.svg)](https://alpinejs.dev/)

**Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".** 

##