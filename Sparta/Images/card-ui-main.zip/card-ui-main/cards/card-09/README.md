# **Card UI - 09**

### [Demo](https://dropways.github.io/card-ui/cards/card-09)

[![Card - 09](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/251514583-2cdae59c-aa9e-499a-b4c4-076eb43032ce.jpg)](https://dropways.github.io/card-ui/cards/card-09/)

## Note

**For Dropdown and other javascript action we used**

[![alpinejs](https://github-production-user-asset-6210df.s3.amazonaws.com/38377336/250278992-60746a40-ffc9-48fc-a6bb-3a7e8e92903f.svg)](https://alpinejs.dev/)

**Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is".**
